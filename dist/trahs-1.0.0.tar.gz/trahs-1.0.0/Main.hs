module Main where

import Trahs

main :: IO ()
main = trahs

